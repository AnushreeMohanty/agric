<div class="row mt-5">
    <h3 class="title text-center bordered">8 Days Weather Forecast Bhubaneswar</h3>

<?php
$cache_file = 'data123.json';
if(file_exists($cache_file)){
  $data = json_decode(file_get_contents($cache_file));
}else{
  // $api_url = 'https://content.api.nytimes.com/svc/weather/v2/current-and-seven-day-forecast.json';
  $api_url = 'https://api.openweathermap.org/data/2.5/onecall?lat=20.2961&lon=85.8245&units=metric&appid=9f23b56e8dcad8299bf4e5a2a3fc932b';
  // echo $api_url;
  $data = file_get_contents($api_url);
  $data = json_decode($data, true);
  $data = $data['daily'];
  // echo gettype($data);
  // var_dump($data);
  foreach($data as $d){
    // $now = DateTime::createFromFormat('U.u', $d['dt']);
    // echo $now->format("d-m-Y H:i:s.u");   
    // print_r($d['dt']);

    ?>
      <div class="col-md-3 p-2">
        <div class="card">
          <div class="card-header">
            <h3 class="text-center"><?php echo date("d/m/Y", $d['dt']);?></h3>
          </div>
          <div class="card-body">
            <p class="lead"><?php echo "Temperature: ".$d['temp']['day'] ?>°C</p>
            <p><?php echo "Wind Speed: ".$d['wind_speed'] ?></p>
            <p><?php echo "Pressure: ".$d['pressure'] ?></p>
            <p><?php echo "Humidity: ".$d['humidity'] ?></p>
          </div>
        </div>
      </div>
    <?php
  }
  
}

// $current = $data->results->current[0];
// $forecast = $data->results->seven_day_forecast;

?>
</div>
<style>

  .aqi-value{
    font-family : "Noto Serif","Palatino Linotype","Book Antiqua","URW Palladio L";
    font-size:30px;
    font-weight:bold;
  }
  h1{
    text-align: center;
    font-size:3em;
  }
  .forecast-block{
  	background-color: #fff!important;
  	width:20% !important;
  }
  .title{
  	background-color:#1b262c;
  	width: 100%;
  	color:#fff;
  	margin-bottom:0px;
  	padding-top:10px;
  	padding-bottom: 10px;
  }
  .bordered{
  	border:1px solid #000;
  }
  .weather-icon{
  	width:40%;
  	font-weight: bold;
  	background-color: #1b262c;
  	padding:10px;
  	border: 1px solid #000;
  }
</style>
